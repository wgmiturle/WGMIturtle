// JavaScript for WGMI DApp
console.log('WGMI Presale initialized');